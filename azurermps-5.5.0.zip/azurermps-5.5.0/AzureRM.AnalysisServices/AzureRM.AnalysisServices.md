﻿---
Module Name: AzureRM.AnalysisServices
Module Guid: acace26c-1775-4100-85c0-20c4d71eaa21
Download Help Link: None_Azure
Help Version: 0.0.1.0
Locale: en-US
---

# AzureRM.AnalysisServices Module
## Description
This topic displays help topics for the Azure AnalysisServices cmdlets.

## AzureRM.AnalysisServices Cmdlets
### [Get-AzureRmAnalysisServicesServer](Get-AzureRmAnalysisServicesServer.md)
Gets the details of an Analysis Services server.

### [New-AzureRmAnalysisServicesServer](New-AzureRmAnalysisServicesServer.md)
Creates a new Analysis Services server

### [Remove-AzureRmAnalysisServicesServer](Remove-AzureRmAnalysisServicesServer.md)
Deletes an instance of Analysis Services server

### [Resume-AzureRmAnalysisServicesServer](Resume-AzureRmAnalysisServicesServer.md)
Resumes an instance of Analysis Services server

### [Set-AzureRmAnalysisServicesServer](Set-AzureRmAnalysisServicesServer.md)
Modifies  an instance of Analysis Services server

### [Suspend-AzureRmAnalysisServicesServer](Suspend-AzureRmAnalysisServicesServer.md)
Suspends an instance of Analysis Services server

### [Test-AzureRmAnalysisServicesServer](Test-AzureRmAnalysisServicesServer.md)
Tests the existence of an instance of Analysis Services server

### [New-AzureRmAnalysisServicesFirewallConfig](New-AzureRmAnalysisServicesFirewallConfig.md)
Creates a new firewall config for Analysis Services server

### [New-AzureRmAnalysisServicesFirewallRule](New-AzureRmAnalysisServicesFirewallRule.md)
Creates a new firewall rule for Analysis Services server

