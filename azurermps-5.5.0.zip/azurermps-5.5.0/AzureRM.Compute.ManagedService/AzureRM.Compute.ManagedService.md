﻿---
Module Name: AzureRM.Compute.ManagedService
Module Guid: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
Download Help Link: 
Help Version: 3.5.0.0
Locale: en-US
---

# AzureRM.Compute.ManagedService Module
## Description
This topic displays the help topics for the Azure Compute Cmdlets.

## AzureRM.Compute.ManagedService Cmdlets
### [ConvertTo-AzureRmVhd](ConvertTo-AzureRmVhd.md)
Convert Hyper-V VM to Azure supported virtual hard disk files
